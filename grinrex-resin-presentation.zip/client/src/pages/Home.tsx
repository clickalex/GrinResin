/**
 * GrinRex Resin style: Lacquered Portfolio — cinematic editorial presentation in ink, cast-honey amber,
 * mineral sage, and chalk. Use asymmetric chapter layouts, the amber memory thread, and restrained glass panels.
 */
import { useEffect, useState } from "react";
import {
  ArrowDown,
  ArrowUpRight,
  Check,
  ChevronRight,
  Download,
  Flower2,
  Gem,
  Menu,
  PackageCheck,
  ShieldCheck,
  Sparkles,
  X,
} from "lucide-react";

type DocumentId = "overview" | "studio" | "catalogue" | "operations" | "investor" | "data" | null;

type SourceProduct = {
  id: number;
  name: string;
  materials: string[];
  tools: string[];
};

const sourceDataUrl = "/manus-storage/grinrex-resin-source-data_dd7cd205.json";

const chapters = [
  ["01", "The promise"],
  ["02", "The opening"],
  ["03", "The system"],
  ["04", "The studio"],
  ["05", "The launch collection"],
  ["06", "The catalogue"],
  ["07", "The discipline"],
  ["08", "The process"],
  ["09", "The market field"],
  ["10", "The roadmap"],
  ["11", "The playbook"],
  ["12", "The investor case"],
  ["13", "The documents"],
];

const documents = {
  overview: {
    number: "01",
    eyebrow: "Business overview",
    title: "The GrinRex Resin proposition",
    download: "/manus-storage/grinrex-resin-business-overview_81d6cfea.md",
    body: [
      "GrinRex Resin is a personalized handmade gifting and keepsake brand for the Indian market, transforming names, photographs, flowers, dates, and occasions into durable resin pieces.",
      "The source plan calls for a controlled 10–20 product launch through Instagram, WhatsApp Business, local exhibitions, gift shops, and online marketplaces. Everyday gifts, personal keepsakes, and functional gifting pieces create a coherent starting range.",
      "Individual sales and custom orders come first; gift combos, wedding orders, corporate gifting, wholesale, workshops, and DIY kits follow only once the studio system is dependable. Customization—not catalogue size or lowest-price positioning—is the core differentiation.",
    ],
  },
  studio: {
    number: "02",
    eyebrow: "Studio & business source reference",
    title: "The full studio foundation",
    download: "/manus-storage/grinrex-resin-studio-source-reference_5fb89717.md",
    body: [
      "This source-backed reference collects the complete business basis: market, model, launch channels, revenue streams, source-plan startup ranges, tools, materials, pricing framework, production process, quality checks, safety requirements, SWOT, marketing, roadmap, metrics, and future expansion lanes.",
      "It preserves planning ranges and operational detail as source material. All figures remain planning inputs that require supplier quotations, product-level costing, and appropriate compliance review before use as commercial commitments.",
    ],
  },
  catalogue: {
    number: "03",
    eyebrow: "Full product catalogue",
    title: "The 150-product opportunity library",
    download: "/manus-storage/grinrex-resin-full-product-catalogue_016c7d4b.md",
    body: [
      "The complete list contains 150 product ideas across jewelry, accessories, personalized gifting, home and living, office and corporate, wedding and festival pieces, gaming and hobby objects, garden items, pet memorials, and art-led keepsakes.",
      "It is an expansion library, not an immediate product promise. The launch strategy still starts with a narrowed 10–20 product edit, with each SKU tested for safety, unit cost, time, quality, demand, packaging, and dispatch risk.",
    ],
  },
  operations: {
    number: "04",
    eyebrow: "Roadmap & internal operations",
    title: "The route from studio to system",
    download: "/manus-storage/grinrex-resin-roadmap-and-operations_12f62ffc.md",
    body: [
      "The source plan estimates an initial setup of ₹10,000–₹14,000: approximately ₹6,000–₹8,000 for essential tools and ₹4,000–₹6,000 for raw materials. These are planning ranges rather than supplier quotations.",
      "The roadmap starts with safe setup, material testing, and a 10–20 product MVP; then standardizes personalization; then expands toward a 50-product range, a 150-product idea library, and eventual dedicated-workspace capacity.",
      "Every SKU records materials, labor, packaging, tool amortization, wastage, fees, margin, order volume, and quality outcome. Each piece follows a defined process from design and mold selection through cure, finishing, quality inspection, and protected dispatch.",
    ],
  },
  investor: {
    number: "05",
    eyebrow: "Investor brief",
    title: "A measured case for growth",
    download: "/manus-storage/grinrex-resin-investor-brief_e402735d.md",
    body: [
      "GrinRex Resin is designed to develop from a disciplined direct-to-consumer keepsake collection into a broader gifting and lifestyle platform with future capability in wedding and corporate gifting, selected wholesale, workshops, DIY kits, and specialist collections.",
      "The source-plan setup reference is ₹10,000–₹14,000 for essential equipment, safety, multipurpose molds, core materials, packaging, and early presentation. It is not a valuation, funding request, revenue forecast, or return claim.",
      "This presentation makes no unverified market-size, revenue, valuation, or return claims. Future investment materials should add verified sales history, product-level margin, operating capacity, customer cohorts, working-capital needs, and specific use-of-funds requirements.",
    ],
  },
  data: {
    number: "06",
    eyebrow: "Source data",
    title: "The original planning data",
    download: sourceDataUrl,
    body: [
      "The original structured source file is available for review and onward planning. It is the source behind the startup ranges, equipment, material, catalogue, costing, process, quality, safety, SWOT, marketing, roadmap, and metric references in this presentation.",
      "The source is retained as a planning document. It should be supplemented with verified supplier pricing, live product tests, legal or safety review where relevant, and actual sales data as the business develops.",
    ],
  },
};

const roadmap = [
  { phase: "01", title: "Starter setup", detail: "Essential tools, safe workspace, restricted palette, multipurpose molds, and sample testing." },
  { phase: "02", title: "MVP catalogue", detail: "Launch 10–12 items, create consistent photography, cost every SKU, and open direct sales." },
  { phase: "03", title: "Customization system", detail: "Build proof approvals for names, photos, flowers, wedding details, and sentimental pieces." },
  { phase: "04", title: "Controlled expansion", detail: "Move toward 50 demand-validated products, bundles, premium editions, and seasonal drops." },
  { phase: "05", title: "Business development", detail: "Introduce selected wholesale, corporate gifting, repeat-customer programs, and marketplace tests." },
  { phase: "06", title: "Scale with proof", detail: "Add SOPs, bulk buying, dedicated workstations, stronger quality control, and B2B capacity." },
];

const metrics = [
  "Material cost per product",
  "Labor time and cost",
  "Packaging, fees & damage rate",
  "Wastage percentage",
  "Gross & net contribution",
  "Order volume & average order value",
  "Repeat or referral demand",
  "Customer acquisition cost",
];

const costComponents = [
  "Resin & hardener",
  "Pigments & inclusions",
  "Hardware & packaging",
  "Tool amortization",
  "Labor & electricity",
  "Wastage, fees & shipping",
];

const swot = [
  { title: "Strengths", summary: "Low setup, personalization, broad gifting potential, online and offline routes." },
  { title: "Constraints", summary: "Cure time, variable conditions, careful finishing, safety controls, early capacity limits." },
  { title: "Openings", summary: "Weddings, corporate gifting, social commerce, kits, workshops, wholesale, and special collections." },
  { title: "Watch-outs", summary: "Low-cost competition, material volatility, copycats, shipping damage, and compliance expectations." },
];

const launchEdit = [
  "Keychains", "Earrings", "Bookmarks", "Coasters", "Personalized Nameplates", "Fridge Magnets",
  "Photo Blocks", "Jewelry Dishes", "Ring Dishes", "Phone Stands", "Wedding Keepsakes", "Pet Memorial Products",
];

function SectionMarker({ number, label }: { number: string; label: string }) {
  return (
    <div className="section-marker">
      <span>{number}</span>
      <i />
      <p>{label}</p>
    </div>
  );
}

export default function Home() {
  const [activeDocument, setActiveDocument] = useState<DocumentId>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [products, setProducts] = useState<SourceProduct[]>([]);
  const [productQuery, setProductQuery] = useState("");
  const [visibleProducts, setVisibleProducts] = useState(24);
  const doc = activeDocument ? documents[activeDocument] : null;

  useEffect(() => {
    let active = true;
    fetch(sourceDataUrl)
      .then((response) => response.json())
      .then((data) => {
        if (active) setProducts(data.product_catalog?.products ?? []);
      })
      .catch(() => {
        if (active) setProducts([]);
      });
    return () => { active = false; };
  }, []);

  const filteredProducts = products.filter((product) => {
    const needle = productQuery.trim().toLowerCase();
    if (!needle) return true;
    return [product.name, ...product.materials, ...product.tools].join(" ").toLowerCase().includes(needle);
  });

  const closeMenu = () => setMenuOpen(false);

  return (
    <main className="site-shell">
      <aside className="chapter-rail" aria-label="Presentation chapters">
        <a href="#top" className="rail-mark brand-rail-lockup" aria-label="GrinRex Resin home">
          <span className="mark-orbit"><span>G</span></span>
          <span className="rail-wordmark">GRINREX<br />RESIN</span>
        </a>
        <div className="rail-track" />
        <nav className="rail-nav">
          {chapters.map(([number, title], index) => (
            <a key={number} href={`#chapter-${index + 1}`} title={`${number} ${title}`}>
              <span>{number}</span>
              <em>{title}</em>
            </a>
          ))}
        </nav>
        <p className="rail-foot">A lasting object<br />for a fleeting moment.</p>
      </aside>

      <header className="mobile-header">
        <a href="#top" className="mobile-mark">
          <span className="mark-orbit"><span>G</span></span>
          <b>GRINREX RESIN</b>
        </a>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle presentation menu">
          {menuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
        {menuOpen && (
          <nav className="mobile-menu">
            {chapters.map(([number, title], index) => (
              <a key={number} href={`#chapter-${index + 1}`} onClick={closeMenu}>
                <span>{number}</span> {title}
              </a>
            ))}
          </nav>
        )}
      </header>

      <div className="page-content" id="top">
        <section className="hero" id="chapter-1">
          <div className="hero-glow hero-glow-one" />
          <div className="hero-glow hero-glow-two" />
          <div className="hero-image" />
          <div className="hero-copy reveal">
            <div className="hero-brand-anchor" aria-label="GrinRex Resin">
              <span className="mark-orbit hero-mark"><span>G</span></span>
              <div><b>GRINREX</b><em>RESIN</em></div>
            </div>
            <p className="micro-label"><span /> GrinRex Resin · presentation 2026</p>
            <h1>Made to keep.<br /><em>Made to grin.</em></h1>
            <p className="hero-intro">A personalized gifting and keepsake brand transforming names, photographs, flowers, and celebrations into objects with staying power.</p>
            <div className="hero-actions">
              <a className="amber-button" href="#chapter-2">Begin the story <ArrowDown size={17} /></a>
              <button className="text-button" onClick={() => setActiveDocument("overview")}>Read the overview <ArrowUpRight size={16} /></button>
            </div>
          </div>
          <div className="hero-aside">
            <p>01 / 13</p>
            <span>Personalized resin<br />gifting & keepsakes</span>
          </div>
          <div className="hero-caption">A name, a flower, a moment—cast to keep.</div>
        </section>

        <section className="chapter opportunity-section" id="chapter-2">
          <SectionMarker number="02" label="The opening" />
          <div className="opportunity-grid">
            <div className="section-lede reveal">
              <p className="micro-label">Where the brand begins</p>
              <h2>Not a general craft store.<br /><em>A meaningful-gift system.</em></h2>
            </div>
            <div className="lede-copy reveal">
              <p>GrinRex Resin enters through the moments mass production cannot quite hold: a wedding date, a familiar flower, a name, a photograph, or a simple sign that someone was considered.</p>
              <p>Its advantage is not a vast catalogue. It is a reliable way to make personal pieces feel intentional, polished, and safe to give.</p>
            </div>
          </div>
          <div className="opportunity-strip reveal">
            <div><Flower2 size={22} /><span>Personalized<br />keepsakes</span></div>
            <div><Gem size={22} /><span>Small-batch<br />craft</span></div>
            <div><PackageCheck size={22} /><span>Gift-ready<br />presentation</span></div>
            <div><ShieldCheck size={22} /><span>Disciplined<br />production</span></div>
          </div>
        </section>

        <section className="chapter system-section" id="chapter-3">
          <SectionMarker number="03" label="The business system" />
          <div className="system-layout">
            <div className="system-image reveal">
              <img src="/manus-storage/grinrex-floral-tray_fc53a30a.jpg" alt="Handmade floral resin keepsake tray" />
              <div className="image-tag">Small studio<br />→ repeatable practice</div>
            </div>
            <div className="system-content reveal">
              <p className="micro-label">A focused route to revenue</p>
              <h2>Begin close to the<br /><em>customer and the craft.</em></h2>
              <p>Individual sales and personalized orders are the first engines. Gift sets and small event orders follow. Corporate gifting, wholesale, workshops, and DIY kits are future branches—not launch distractions. The route is designed for an Indian home-studio context: digital discovery, direct conversation, and selected local selling.</p>
              <div className="revenue-stack">
                <div><span>01</span><b>Direct pieces</b><p>Everyday gifts that invite discovery and repeat purchase.</p></div>
                <div><span>02</span><b>Personalization</b><p>Names, dates, photos, and flowers that make price less comparable.</p></div>
                <div><span>03</span><b>Occasion orders</b><p>Wedding and gifting sets that lift order value once the system is ready.</p></div>
                <div><span>04</span><b>Channel depth</b><p>Corporate, wholesale, DIY kits, and workshops only after the core process holds.</p></div>
              </div>
            </div>
          </div>
        </section>

        <section className="chapter studio-section" id="chapter-4">
          <SectionMarker number="04" label="The studio foundation" />
          <div className="studio-heading reveal">
            <div>
              <p className="micro-label">From source plan to working bench</p>
              <h2>Start with the<br /><em>right constraints.</em></h2>
            </div>
            <p>The source plan assumes a home-based manufacturing model with custom orders, online sales, and local selling. The first studio should remain deliberately compact: safety, repeatability, and a limited product edit come before equipment breadth.</p>
          </div>
          <div className="studio-grid">
            <article className="studio-card reveal"><span>01</span><h3>Core bench</h3><p>Scale, mixing cups and sticks, silicone molds, heat gun, drill, sandpaper, pliers, beakers, and protected storage form the essential working base.</p></article>
            <article className="studio-card reveal"><span>02</span><h3>Material palette</h3><p>Epoxy resin and hardener, pigments, mica, alcohol ink, foil, dried botanicals, hardware, and protective packaging make the first collection possible.</p></article>
            <article className="studio-card reveal"><span>03</span><h3>Safety envelope</h3><p>Use product instructions and SDS guidance, suitable protective wear, ventilation, controlled access, and boundaries around food-contact and heat-exposed use.</p></article>
          </div>
          <div className="startup-snapshot reveal">
            <div><span>Source-plan setup range</span><strong>₹10k–₹14k</strong></div>
            <p>Essential tools: ₹6k–₹8k · Initial raw materials: ₹4k–₹6k. These are source planning ranges, not supplier quotations. Advanced tools such as pressure pots, rotary tools, and polishing machines remain later-stage decisions.</p>
          </div>
          <button className="document-inline-link ink-link" onClick={() => setActiveDocument("studio")}>Open the complete studio, tool & material reference <ArrowUpRight size={16} /></button>
        </section>

        <section className="chapter collection-section" id="chapter-5">
          <SectionMarker number="05" label="The launch collection" />
          <div className="collection-heading reveal">
            <div>
              <p className="micro-label">A 150-product idea library, distilled</p>
              <h2>Twelve launch products.<br /><em>One coherent point of view.</em></h2>
            </div>
            <p>Start with three linked families. The catalogue grows only when quality, margin, and demand all agree.</p>
          </div>
          <div className="collection-panels">
            <article className="collection-card reveal card-gift">
              <span className="card-number">01</span>
              <h3>Everyday gifts</h3>
              <p>Keychains, bookmarks, fridge magnets, and earrings bring customers into the brand.</p>
              <div className="card-image everyday" />
              <small>Discoverable · small-format · giftable</small>
            </article>
            <article className="collection-card reveal card-keep">
              <span className="card-number">02</span>
              <h3>Personal keepsakes</h3>
              <p>Nameplates, photo blocks, jewelry dishes, and ring dishes carry the emotional signature.</p>
              <div className="card-image keepsake" />
              <small>Custom · meaningful · higher value</small>
            </article>
            <article className="collection-card reveal card-home">
              <span className="card-number">03</span>
              <h3>Home & gifting décor</h3>
              <p>Coasters, phone stands, compact trays, and curated sets create functional gifting moments.</p>
              <div className="card-image home" />
              <small>Useful · bundle-ready · seasonal</small>
            </article>
          </div>
          <div className="launch-edit reveal">
            <div className="launch-edit-top"><p className="micro-label">The recommended 12-product launch edit</p><span>Source-backed MVP</span></div>
            <div className="launch-tags">{launchEdit.map((product, index) => <span key={product}><b>{String(index + 1).padStart(2, "0")}</b>{product}</span>)}</div>
            <a className="text-button launch-catalogue-link" href="#chapter-6">Browse the complete 150-product catalogue <ArrowDown size={16} /></a>
          </div>
        </section>

        <section className="chapter catalogue-section" id="chapter-6">
          <SectionMarker number="06" label="The full product catalogue" />
          <div className="catalogue-heading reveal">
            <div><p className="micro-label">150 source products · one browsable library</p><h2>The whole range,<br /><em>kept in context.</em></h2></div>
            <p>The source list spans jewelry, keepsakes, home and living, office and corporate pieces, celebrations, hobby objects, garden items, and pet memorial products. Browse it here, then keep the sales range disciplined.</p>
          </div>
          <div className="catalogue-family-grid reveal">
            <span>Jewelry & accessories</span><span>Everyday gifting & keepsakes</span><span>Home & living</span><span>Desk, office & corporate</span><span>Celebrations & seasonal</span><span>Hobby, gaming & collectibles</span><span>Garden, pet & memorial</span>
          </div>
          <div className="catalogue-controls reveal">
            <label htmlFor="catalogue-search">Search all product ideas</label>
            <input id="catalogue-search" value={productQuery} onChange={(event) => { setProductQuery(event.target.value); setVisibleProducts(24); }} placeholder="Try ‘wedding’, ‘clock’, ‘keychain’ or ‘flower’" />
            <p>{products.length ? `${filteredProducts.length} of ${products.length} source products` : "Loading source catalogue…"}</p>
          </div>
          <div className="product-grid">
            {filteredProducts.slice(0, visibleProducts).map((product) => (
              <article className="product-chip reveal" key={product.id}>
                <span>{String(product.id).padStart(3, "0")}</span>
                <h3>{product.name}</h3>
                <p>{product.materials.slice(0, 3).join(" · ").replaceAll("_", " ")}</p>
              </article>
            ))}
          </div>
          {filteredProducts.length > visibleProducts && <button className="catalogue-more" onClick={() => setVisibleProducts((current) => current + 24)}>Show 24 more products <ArrowDown size={16} /></button>}
          {!filteredProducts.length && products.length > 0 && <p className="catalogue-empty">No source products match that search.</p>}
          <button className="document-inline-link ink-link" onClick={() => setActiveDocument("catalogue")}>Open or download the full 150-product reference <ArrowUpRight size={16} /></button>
        </section>

        <section className="chapter discipline-section" id="chapter-7">
          <SectionMarker number="07" label="Costing, quality & safety" />
          <div className="discipline-layout">
            <div className="discipline-title reveal">
              <p className="micro-label">Quality is the product</p>
              <h2>A beautiful pour<br />needs a rigorous <em>finish.</em></h2>
            </div>
            <div className="discipline-grid reveal">
              <div className="discipline-item"><span>01</span><h3>Cost what is real</h3><p>Include materials, labor, packaging, overhead, payment fees, shipping, and wastage before price is set.</p></div>
              <div className="discipline-item"><span>02</span><h3>Standardize the work</h3><p>Document the route from design and mold selection through cure, trimming, polishing, assembly, and safe handling.</p></div>
              <div className="discipline-item"><span>03</span><h3>Protect the result</h3><p>Inspect cure, surface, personalization, hardware, and packaging before every piece leaves the studio.</p></div>
              <div className="discipline-item"><span>04</span><h3>Respect the boundary</h3><p>Do not make food-contact or heat-use claims unless the material and complete product design are verified for that use.</p></div>
            </div>
          </div>
          <div className="cost-basis reveal">
            <p className="micro-label">Every source cost component belongs in the SKU file</p>
            <div>{costComponents.map((component, index) => <span key={component}><b>{String(index + 1).padStart(2, "0")}</b>{component}</span>)}</div>
            <small>Source category examples: small raw materials ₹15–₹40; medium ₹30–₹100; large ₹60–₹250; premium ₹150–₹1,000+. Tool amortization must be tracked alongside the product decision.</small>
          </div>
          <div className="formula-card reveal">
            <p>Pricing guardrail</p>
            <strong>Material <i>+</i> labor <i>+</i> packaging <i>+</i> overhead <i>+</i> fees <i>+</i> profit</strong>
          </div>
        </section>

        <section className="chapter process-section" id="chapter-8">
          <SectionMarker number="08" label="The production & care process" />
          <div className="process-heading reveal"><div><p className="micro-label">Every piece earns its finish</p><h2>From design to<br /><em>protected dispatch.</em></h2></div><p>The source process is a 16-step workflow: design, mold selection, workspace preparation, measurement, mixing, inclusion, pour, bubble removal, cure, demold, finishing, assembly, inspection, packaging, storage, and dispatch.</p></div>
          <div className="process-steps reveal">
            <article><span>01</span><h3>Prepare</h3><p>Choose the design and mold, set up the bench, follow the resin maker’s measurement instructions, then mix with care.</p></article>
            <article><span>02</span><h3>Cast</h3><p>Add pigments or inclusions, pour, address bubbles as directed, and allow complete curing before demolding.</p></article>
            <article><span>03</span><h3>Finish</h3><p>Trim, sand, drill where needed, polish, and attach hardware only after the cast surface is fully ready.</p></article>
            <article><span>04</span><h3>Release</h3><p>Confirm cure, bubbles, cracks, dimensions, personalization, hardware, finished edges, protection, and product-specific safety requirements.</p></article>
          </div>
          <div className="safety-band reveal"><ShieldCheck size={21} /><p><b>Safety is non-negotiable.</b> Follow product SDS and manufacturer guidance; use suitable protection and ventilation; avoid skin and eye contact; control access; and avoid food-contact or heat-use claims unless the full material-and-design system is verified for that use.</p></div>
        </section>

        <section className="chapter market-section" id="chapter-9">
          <SectionMarker number="09" label="The market & risk field" />
          <div className="market-heading reveal"><div><p className="micro-label">The opportunity needs a clear view</p><h2>Sell with taste.<br /><em>Operate with eyes open.</em></h2></div><p>GrinRex Resin is positioned as an affordable-to-premium customized handmade resin offering. The source plan combines social and direct commerce with exhibitions, gift stores, corporate conversation, marketplaces, and an owned website.</p></div>
          <div className="swot-grid">{swot.map((item, index) => <article className="swot-card reveal" key={item.title}><span>0{index + 1}</span><h3>{item.title}</h3><p>{item.summary}</p></article>)}</div>
          <div className="content-system reveal"><p className="micro-label">Marketing content system</p><div><span>Product photography</span><span>Making reels</span><span>Customization stories</span><span>Packaging videos</span><span>Festival collections</span><span>Behind the scenes</span><span>Educational content</span></div></div>
        </section>

        <section className="chapter roadmap-section" id="chapter-10">
          <div className="roadmap-backdrop" />
          <SectionMarker number="10" label="The roadmap" />
          <div className="roadmap-title reveal">
            <p className="micro-label">Build through evidence</p>
            <h2>From first pour<br />to a <em>durable system.</em></h2>
          </div>
          <div className="roadmap-list">
            {roadmap.map((item, index) => (
              <article className="roadmap-row reveal" key={item.phase}>
                <span className="roadmap-phase">{item.phase}</span>
                <h3>{item.title}</h3>
                <p>{item.detail}</p>
                <ChevronRight size={20} />
                <div className="roadmap-dot" style={{ "--delay": `${index * 0.08}s` } as React.CSSProperties} />
              </article>
            ))}
          </div>
          <button className="document-inline-link" onClick={() => setActiveDocument("operations")}>Read the full roadmap & operating playbook <ArrowUpRight size={16} /></button>
        </section>

        <section className="chapter playbook-section" id="chapter-11">
          <SectionMarker number="11" label="The internal playbook" />
          <div className="playbook-grid">
            <div className="playbook-copy reveal">
              <p className="micro-label">What gets managed gets stronger</p>
              <h2>Every product tells<br />a <em>useful story.</em></h2>
              <p>GrinRex Resin turns craft knowledge into decision-quality information. Each SKU is not just made—it is measured for effort, quality, demand, and contribution.</p>
              <button className="amber-button" onClick={() => setActiveDocument("operations")}>Open operating playbook <ArrowUpRight size={17} /></button>
            </div>
            <div className="metrics-cast reveal">
              <div className="metrics-top"><span>SKU evidence card</span><em>Live with every order</em></div>
              {metrics.map((metric, index) => <div className="metric-row" key={metric}><span>0{index + 1}</span><b>{metric}</b><Check size={16} /></div>)}
              <p className="metrics-note">The purpose is not bureaucracy. It is knowing which pieces deserve another pour.</p>
            </div>
          </div>
        </section>

        <section className="chapter investor-section" id="chapter-12">
          <SectionMarker number="12" label="The investor case" />
          <div className="investor-layout">
            <div className="investor-top reveal">
              <p className="micro-label">A measured case for growth</p>
              <h2>Fund the proof,<br />then fund the <em>reach.</em></h2>
            </div>
            <div className="investor-copy reveal">
              <p>The source plan provides a controlled setup reference of ₹10,000–₹14,000 for essential equipment, safety, multipurpose molds, core materials, protective packaging, and early presentation. It is a starting cost reference—not a valuation, forecast, or capital request.</p>
              <p>Growth should follow evidence—reliable unit costs, stable quality, demand-validated products, operating capacity, and repeat or referral signals.</p>
            </div>
          </div>
          <div className="investor-cards">
            <article className="investor-card reveal"><span>01</span><h3>Use of funds</h3><p>Prioritize essential equipment, safety, molds, core materials, packaging, and product presentation.</p></article>
            <article className="investor-card reveal"><span>02</span><h3>Milestone logic</h3><p>Prove demand, margin, and repeatability before expanding the catalogue or B2B commitment.</p></article>
            <article className="investor-card reveal"><span>03</span><h3>Investor discipline</h3><p>No unverified market, revenue, valuation, or return claims are presented here.</p></article>
          </div>
          <div className="expansion-index reveal"><p className="micro-label">Source-defined future expansion lanes</p><div><span>Jewelry brand</span><span>Home décor</span><span>Wedding collection</span><span>Corporate gifting</span><span>Pet memorials</span><span>Gaming collection</span><span>DIY kits</span><span>Workshops</span><span>Wholesale</span><span>Custom molds</span><span>Supplies store</span><span>Design marketplace</span></div></div>
          <button className="document-inline-link" onClick={() => setActiveDocument("investor")}>Open investor brief <ArrowUpRight size={16} /></button>
        </section>

        <section className="chapter library-section" id="chapter-13">
          <SectionMarker number="13" label="The document library" />
          <div className="library-title reveal">
            <p className="micro-label">Everything, in sequence</p>
            <h2>The story. The route.<br /><em>The working documents.</em></h2>
            <p>Each document continues the presentation in the order it was introduced. Read within the site, download the working reference, or inspect the original structured source data.</p>
          </div>
          <div className="document-library">
            {(Object.entries(documents) as [Exclude<DocumentId, null>, typeof documents.overview][]).map(([id, item]) => (
              <article className="document-card reveal" key={id}>
                <div className="document-card-top"><span>{item.number}</span><Sparkles size={17} /></div>
                <p>{item.eyebrow}</p>
                <h3>{item.title}</h3>
                <div className="document-actions">
                  <button onClick={() => setActiveDocument(id)}>Read in site <ArrowUpRight size={15} /></button>
                  <a href={item.download} download>Download <Download size={15} /></a>
                </div>
              </article>
            ))}
          </div>
        </section>

        <footer className="site-footer">
          <div className="footer-mark brand-footer-lockup"><span className="mark-orbit"><span>G</span></span><b>GRINREX<br /><em>RESIN</em></b></div>
          <p>A lasting object for a fleeting moment.</p>
          <a href="#top">Back to first chapter <ArrowUpRight size={15} /></a>
        </footer>
      </div>

      {doc && (
        <div className="document-modal" role="dialog" aria-modal="true" aria-labelledby="document-title">
          <button className="modal-backdrop" aria-label="Close document" onClick={() => setActiveDocument(null)} />
          <article className="document-sheet">
            <button className="close-document" onClick={() => setActiveDocument(null)} aria-label="Close document"><X size={19} /></button>
            <div className="document-sheet-header"><span>{doc.number}</span><p>{doc.eyebrow}</p></div>
            <h2 id="document-title">{doc.title}</h2>
            <div className="document-sheet-copy">{doc.body.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}</div>
            <a className="amber-button" href={doc.download} download>Download source document <Download size={17} /></a>
          </article>
        </div>
      )}
    </main>
  );
}
